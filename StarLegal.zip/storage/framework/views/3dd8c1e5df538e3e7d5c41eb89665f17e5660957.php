<?php $__env->startSection('content'); ?>
<main class="main">
    <div class="container-fluid">
        <div class="animated fadeIn">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="icon-tag icon-gradient bg-deep-blue"></i>
                </div>
                <div>Requested Documents</div>
            </div>
            <!-- /.card-->
            <div class="row pt-3">
                <div class="col">
                    <table id="request-table" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Date Requested</th>
                                <th>Document Type</th>
                                <th>The Parties</th>
                                <th>Purpose Agreement</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <input type="hidden" id="acc_token" name="acc_token" value="APPROVER">
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\001_Project\003_StarLegal\StarLegal\resources\views/approver/docRequest.blade.php ENDPATH**/ ?>