<?php $__env->startSection('content'); ?>
<main class="main">
    <div class="container-fluid">
        <div class="animated fadeIn">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="icon-speedometer icon-gradient bg-mean-fruit"></i>
                </div>
                <div>Dashboard</div>
            </div>
            <!-- /.card-->
            <div class="row">
                <div class="col-sm-6 col-lg-3">
                    <div class="brand-card card-hover">
                        <div class="brand-card-header bg-facebook">
                            <i class="fa fa-pencil-square-o "></i>
                            <div class="chart-wrapper">
                                <canvas id="social-box-chart-1" height="90"></canvas>
                            </div>
                        </div>
                        <div class="brand-card-body text-center">
                            <div>
                                <div class="text-value">5</div>
                                <div class="text-muted small">Need To Approve</div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col-->
                <div class="col-sm-6 col-lg-3">
                    <div class="brand-card card-hover">
                        <div class="brand-card-header bg-twitter">
                            <i class="fa fa-tags"></i>
                            <div class="chart-wrapper">
                                <canvas id="social-box-chart-2" height="90"></canvas>
                            </div>
                        </div>
                        <div class="brand-card-body text-center">
                            <div>
                                <div class="text-value">7</div>
                                <div class="text-muted small">Requested Docs</div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col-->
                <div class="col-sm-6 col-lg-3">
                    <div class="brand-card card-hover">
                        <div class="brand-card-header bg-linkedin">
                            <i class="fa fa-search"></i>
                            <div class="chart-wrapper">
                                <canvas id="social-box-chart-3" height="90"></canvas>
                            </div>
                        </div>
                        <div class="brand-card-body text-center">
                            <div>
                                <div class="text-value">3</div>
                                <div class="text-muted small">Reviewed Docs</div>
                            </div>
                        </div>
                    </div>
                </div>
              <!-- /.col-->
              <div class="col-sm-6 col-lg-3">
                <div class="brand-card card-hover">
                  <div class="brand-card-header bg-google-plus">
                    <i class="fa fa-gears"></i>
                    <div class="chart-wrapper">
                      <canvas id="social-box-chart-4" height="90"></canvas>
                    </div>
                  </div>
                  <div class="brand-card-body text-center">
                    <div>
                      <div class="text-value">5</div>
                      <div class="text-muted small">Document In Process</div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.col-->
            </div>
            <div class="row">
                <div class="col-sm-6 col-lg-3">
                    <div class="brand-card card-hover">
                        <div class="brand-card-header bg-github">
                            <i class="fa fa-group"></i>
                            <div class="chart-wrapper">
                                <canvas id="social-box-chart-1" height="90"></canvas>
                            </div>
                        </div>
                        <div class="brand-card-body text-center">
                            <div>
                                <div class="text-value">10</div>
                                <div class="text-muted small">PIC Available</div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col-->
                <div class="col-sm-6 col-lg-3">
                    <div class="brand-card card-hover">
                        <div class="brand-card-header bg-html5">
                            <i class="fa fa-legal"></i>
                            <div class="chart-wrapper">
                                <canvas id="social-box-chart-2" height="90"></canvas>
                            </div>
                        </div>
                        <div class="brand-card-body text-center">
                            <div>
                                <div class="text-value">25</div>
                                <div class="text-muted small">Approved Docs</div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.col-->
                <div class="col-sm-6 col-lg-3">
                    <div class="brand-card card-hover">
                    <div class="brand-card-header bg-openid">
                        <i class="fa fa-hourglass-1"></i>
                        <div class="chart-wrapper">
                        <canvas id="social-box-chart-3" height="90"></canvas>
                        </div>
                    </div>
                    <div class="brand-card-body text-center">
                        <div>
                        <div class="text-value">0</div>
                        <div class="text-muted small">Hold Docs</div>
                        </div>
                    </div>
                    </div>
                </div>
                <!-- /.col-->
                <div class="col-sm-6 col-lg-3">
                    <div class="brand-card card-hover">
                    <div class="brand-card-header bg-stack-overflow">
                        <i class="fa fa-check-square-o"></i>
                        <div class="chart-wrapper">
                        <canvas id="social-box-chart-4" height="90"></canvas>
                        </div>
                    </div>
                    <div class="brand-card-body text-center">
                        <div>
                        <div class="text-value">123</div>
                        <div class="text-muted small">Completed Docs</div>
                        </div>
                    </div>
                    </div>
                </div>
                <!-- /.col-->
            </div>
            <!-- /.row-->
            <div class="row">
              <div class="col-md-12">
                <div class="card">
                  <div class="card-header" style="font-weight:600">User Activities Chart / year </div>
                  <div class="card-body">
                    <div class="row">
                      <div class="col">
                        <div class="row">
                          <div class="col-sm-6">
                            <div class="callout callout-info">
                              <small class="text-muted">Request</small>
                              <br>
                              <strong class="h4">9,123</strong>
                              <div class="chart-wrapper">
                                <canvas id="sparkline-chart-1" width="100" height="30"></canvas>
                              </div>
                            </div>
                          </div>
                          <!-- /.col-->
                          <div class="col-sm-6">
                            <div class="callout callout-success">
                              <small class="text-muted">Completed</small>
                              <br>
                              <strong class="h4">22,643</strong>
                              <div class="chart-wrapper">
                                <canvas id="sparkline-chart-2" width="100" height="30"></canvas>
                              </div>
                            </div>
                          </div>
                          <!-- /.col-->
                        </div>
                        <!-- /.row-->
                        <hr class="mt-0">
                        <div class="progress-group mb-4">
                          <div class="progress-group-prepend">
                            <span class="progress-group-text">Week 4</span>
                          </div>
                          <div class="progress-group-bars">
                            <div class="progress progress-xs">
                              <div class="progress-bar bg-info" role="progressbar" style="width: 56%" aria-valuenow="56" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="progress progress-xs">
                              <div class="progress-bar bg-success" role="progressbar" style="width: 94%" aria-valuenow="94" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                          </div>
                        </div>
                        <div class="progress-group mb-4">
                          <div class="progress-group-prepend">
                            <span class="progress-group-text">Week 3</span>
                          </div>
                          <div class="progress-group-bars">
                            <div class="progress progress-xs">
                              <div class="progress-bar bg-info" role="progressbar" style="width: 12%" aria-valuenow="12" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="progress progress-xs">
                              <div class="progress-bar bg-success" role="progressbar" style="width: 67%" aria-valuenow="67" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                          </div>
                        </div>
                        <div class="progress-group mb-4">
                          <div class="progress-group-prepend">
                            <span class="progress-group-text">Week 2</span>
                          </div>
                          <div class="progress-group-bars">
                            <div class="progress progress-xs">
                              <div class="progress-bar bg-info" role="progressbar" style="width: 43%" aria-valuenow="43" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="progress progress-xs">
                              <div class="progress-bar bg-success" role="progressbar" style="width: 91%" aria-valuenow="91" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                          </div>
                        </div>
                        <div class="progress-group mb-4">
                          <div class="progress-group-prepend">
                            <span class="progress-group-text">Week 1</span>
                          </div>
                          <div class="progress-group-bars">
                            <div class="progress progress-xs">
                              <div class="progress-bar bg-info" role="progressbar" style="width: 22%" aria-valuenow="22" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <div class="progress progress-xs">
                              <div class="progress-bar bg-success" role="progressbar" style="width: 73%" aria-valuenow="73" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.col-->
            </div>
            <!-- /.row-->
        </div>
      </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\001_Project\003_StarLegal\StarLegal\resources\views/approver/dashboard.blade.php ENDPATH**/ ?>