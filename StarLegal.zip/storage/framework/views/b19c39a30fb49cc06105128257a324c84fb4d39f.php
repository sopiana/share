<!DOCTYPE html>
<!--
* CoreUI - Free Bootstrap Admin Template
* @version  v2.1.15
* @link  https://coreui.io
* Copyright (c) 2018 creativeLabs Łukasz Holeczek
* Licensed under MIT (https://coreui.io/license)
-->
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="description" content="Star Legal">
    <meta name="author" content="Star Legal">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(env('APP_NAME', 'Star Legal')); ?></title>
    <link rel="icon" type="image/ico" href="./img/favicon.ico" sizes="any" />
    <!-- Styles -->
    <link href="<?php echo e(URL::asset('/assets/css/main.css')); ?>" rel="stylesheet">
</head>
<?php if(Route::currentRouteName()=='login'): ?>
<body class="app flex-row align-items-center">
    <div class="app-body">
    <?php echo $__env->yieldContent('content'); ?>
    </div>
<?php else: ?>
<body class="app header-fixed sidebar-fixed aside-menu-fixed sidebar-lg-show">
    <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="app-body">
    <?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    </div>
    <footer class="app-footer text-center">
        <div>
            <a href="https://coreui.io">Star Legal</a>
            <span>&copy; 2019</span>
        </div>
    </footer>

    
    <!-- Scripts -->
    <script src="<?php echo e(URL::asset('/assets/js/action_authorized.js')); ?>" defer></script>
    
<?php endif; ?>
</body>
<?php echo $__env->yieldContent('modal'); ?>
</html>
<?php /**PATH D:\001_Project\003_StarLegal\StarLegal\resources\views/layout/app.blade.php ENDPATH**/ ?>