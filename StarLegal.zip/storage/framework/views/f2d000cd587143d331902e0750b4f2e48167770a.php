<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" crossorigin="anonymous">
        <title>Expired file notification</title>
    </head>
    <body class="pl-2"  style="font-size: 0.875rem;">
        <h3>Hi, <?php echo e($username); ?></h3>
        <p>Following file will be expired in <?php echo e($expirationDay); ?> days. For detailed information click this</p>
        <p>
            <table class="table" style="font-size: 0.875rem; max-width:60%">
                <tr>
                    <th width="200px">Document Name</th><td><?php echo e($docData->doc_name); ?></td>
                </tr>
                <tr>
                    <th>File Submisstion Date</th><td><?php echo e($docData->created_at); ?></td>
                </tr>
                <tr>
                    <th>Company Name</th><td><?php echo e($docData->company_name); ?></td>
                </tr>
                <tr>
                    <th>Document Type</th><td><?php echo e($docData->type); ?></td>
                </tr>
                <tr>
                    <th>Date of Agreement</th><td><?php echo e($docData->agreement_date); ?></td>
                </tr>
                <tr>
                    <th>Agreement Number</th><td><?php echo e($docData->agreement_number); ?></td>
                </tr>
                <tr>
                    <th>Parties</th><td><?php echo e($docData->parties); ?></td>
                </tr>
                <tr>
                    <th>Expiration Date</th><td><?php echo e($docData->expire_date); ?></td>
                </tr>
                <tr>
                    <th>Description</th><td><?php echo e($docData->description); ?></td>
                </tr>
                <tr>
                    <td class="text-center" colspan="2">
                        <a href="<?php echo e(route('sharedFile',$docData->id)); ?>" class="btn btn-primary">Download</a>
                    </td>
                </tr>
            </table>
        </p>
    </body>
</html>
<?php /**PATH D:\001_Project\003_StarLegal\StarLegal\resources\views/email/expiredFileNotif.blade.php ENDPATH**/ ?>