<div class="sidebar">
    <nav class="sidebar-nav">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
            <i class="nav-icon icon-speedometer"></i> Dashboard
          </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('request')); ?>">
                <i class="nav-icon icons icon-tag"></i> Requested
                <span class="badge badge-pill badge-danger">5</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('review')); ?>">
                <i class="nav-icon icon-magnifier"></i> Reviewed
                <span class="badge badge-pill badge-info">3</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('complete')); ?>">
                <i class="nav-icon icon-star"></i> Completed
                <span class="badge badge-pill badge-success">6</span>
            </a>
        </li>
        <?php if($userInfo->role=='APPROVER' || $userInfo->role=='LEGAL'): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('share')); ?>">
                <i class="nav-icon icon-cursor"></i> Shared
            </a>
        </li>
        <?php endif; ?>
      </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
  </div>
<?php /**PATH D:\001_Project\003_StarLegal\StarLegal\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>