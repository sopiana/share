<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function(){return redirect()->route('login');})->name('root');
Route::get('/home', function(){return redirect()->route('dashboard');});
Route::get('/dashboard', 'DashboardController@index')->name('dashboard');
Route::get('/profile', 'DashboardController@profile')->name('profile');
Route::get('/request','DashboardController@request' )->name('request');
Route::get('/review', 'DashboardController@review')->name('review');
Route::get('/complete', 'DashboardController@complete')->name('complete');
Route::get('/share/{folderId?}/{phrase?}', 'DashboardController@share')->name('share');
Route::post('/addFolder','DashboardController@addFolder')->name('addFolder');
Route::post('/addFile','DashboardController@addFile')->name('addFile');
Route::post('/changePassword','DashboardController@changePassword')->name('changePassword');
Route::post('/changeProfile','DashboardController@changeProfile')->name('changeProfile');
Route::post('/doDocShare','DashboardController@doDocShare')->name('doDocShare');
Route::post('/doDocDelete','DashboardController@doDocDelete')->name('doDocDelete');
Route::get('/sharedFile/{fileName}','DashboardController@sharedFile')->name('sharedFile');
Auth::routes();


Route::get('/api/getRequestDocs', 'ApiController@getRequestDocs')->name('api.getRequestDocs');
Route::get('/api/getSharedFolders/{folderId?}', 'ApiController@getSharedFolders')->name('api.getSharedFolders');
Route::get('/api/getSharedDocs/{folderId?}', 'ApiController@getSharedDocs')->name('api.getSharedDocs');
Route::get('/api/getSharedFoldersDocs/{folderId?}/{phrase?}', 'ApiController@getSharedFoldersDocs')->name('api.getSharedFoldersDocs');
Route::get('/api/getDocPath/{folderId?}', 'ApiController@getDocPath')->name('api.getDocPath');
Route::get('/api/getDocType', 'ApiController@getDocType')->name('api.getDocType');
Route::post('/api/getAuthorizeUser', 'ApiController@getAuthorizeUser')->name('api.getAuthorizeUser');
Route::post('/api/getDownloadLinks', 'ApiController@getDownloadLinks')->name('api.getDownloadLinks');

Route::get('/testMail','EmailController@send');
Route::get('/test','EmailController@index');
