<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ViewAssignment extends Migration
{
    private function createFolderShareView()
    {
        DB::statement('DROP VIEW IF EXISTS `folder_share_view`');
        DB::statement("CREATE VIEW folder_share_view AS(
            SELECT 'FOLDER' as type,
                folder_share.id as doc_id,
                folder_share.folder_id,
                folder_user.user_id,
                folder_share.folder_name as doc_name,
                folder_share.creator_id as submitter_id,
                NULL as company_name,
                NULL as doc_type,
                NULL as agreement_date,
                NULL as agreement_number,
                NULL as parties,
                NULL as expire_date,
                NULL as remark,
                folder_share.description,
                NULL as attachment,
                folder_share.created_at as date_creation
            FROM `folder_share`
            LEFT OUTER JOIN folder_user on (folder_share.id = folder_user.folder_id))");
    }

    private function createDocShareView()
    {
        DB::statement('DROP VIEW IF EXISTS `doc_share_view`');
        DB::statement("CREATE VIEW doc_share_view AS(
            SELECT 'DOC' as type,
                doc_share.id as doc_id,
                doc_share.folder_id,
                doc_user.user_id,
                doc_share.doc_name,
                doc_share.submitter_id as submitter_id,
                doc_share.company_name,
                doc_share.doc_type,
                doc_share.agreement_date,
                doc_share.agreement_number,
                doc_share.parties,
                doc_share.expire_date,
                doc_share.remark,
                doc_share.description,
                doc_share.attachment,
                doc_share.created_at as date_creation
            FROM `doc_share`
            LEFT OUTER JOIN doc_user on (doc_share.id = doc_user.doc_id))");
    }
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        $this->createFolderShareView();
        $this->createDocShareView();
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //do nothing
    }
}
