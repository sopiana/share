<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDocRequestTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('doc_request');
        Schema::create('doc_request', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('doc_type',false,true);
            $table->foreign('doc_type')->references('id')->on('doc_type');
            $table->text('purpose')->nullable();
            $table->string('parties', 1024);
            $table->text('description')->nullable();
            $table->string('commercial_terms', 512);
            $table->string('transaction_value', 512);
            $table->string('late_payment_toleration', 512);
            $table->string('condition_precedent', 512);
            $table->string('termination_terms', 512);
            $table->string('payment_terms', 512);
            $table->string('delay_penalty', 512);
            $table->string('guarantee', 512);
            $table->string('agreement_terms', 512);

            $table->string('attch_akta', 512);
            $table->string('attch_npwp', 512);
            $table->string('attch_tdp', 512);
            $table->string('attch_ktp', 512);
            $table->string('attch_comp_profile', 512);
            $table->string('attch_others', 512);

            $table->string('status');
            $table->bigInteger('requester_id', false, true);
            $table->foreign('requester_id')->references('id')->on('users');
            $table->bigInteger('pic_id', false, true);
            $table->foreign('pic_id')->references('id')->on('users');
            $table->bigInteger('approver_id', false, true);
            $table->foreign('approver_id')->references('id')->on('users');
            $table->timestamps();
        });
        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('doc_request_tables');
        Schema::enableForeignKeyConstraints();
    }
}
