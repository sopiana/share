<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDocReviewTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('doc_review');
        Schema::create('doc_review', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('doc_type',false,true);
            $table->foreign('doc_type')->references('id')->on('doc_type');
            $table->text('purpose')->nullable();
            $table->string('parties', 1024);
            $table->text('description')->nullable();
            $table->string('commercial_terms', 512);
            $table->string('transaction_value', 512);
            $table->string('late_payment_toleration', 512);
            $table->string('condition_precedent', 512);
            $table->string('termination_terms', 512);
            $table->string('payment_terms', 512);
            $table->string('delay_penalty', 512);
            $table->string('guarantee', 512);
            $table->string('agreement_terms', 512);

            $table->string('attch_file', 512);

            $table->string('status');
            $table->bigInteger('requester_id', false, true);
            $table->foreign('requester_id')->references('id')->on('users');
            $table->bigInteger('pic_id', false, true);
            $table->foreign('pic_id')->references('id')->on('users');
            $table->bigInteger('approver_id', false, true);
            $table->foreign('approver_id')->references('id')->on('users');
            $table->timestamps();
        });
        Schema::enableForeignKeyConstraints();
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::disableForeignKeyConstraints();
        Schema::dropIfExists('doc_review_tables');
        Schema::enableForeignKeyConstraints();
    }
}
