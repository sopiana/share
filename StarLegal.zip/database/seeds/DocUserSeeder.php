<?php

use Illuminate\Database\Seeder;
use App\Model\DocUser;
use Faker\Factory as Faker;
class DocUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        //get All files
        $docs = DB::table('doc_share')->select('id','submitter_id')->get();
        foreach($docs as $doc)
        {
            $userNum = rand(0,5);
            for($i=0;$i<$userNum;)
            {
                try{
                    //get APPROVER and LEGAL except the creator
                    $ApproverLegals = DB::table('users')->select('id','role')->where('id', '!=', $doc->submitter_id)->
                        whereIn('role',['LEGAL','APPROVER'])->get();
                    DocUser::create(array(
                        "doc_id"=>$doc->id,
                        "user_id"=>$faker->randomElement($ApproverLegals)->id
                    ));
                    $i++;
                }
                catch(Exception $e)
                {
                    //do nothing
                }
            }
        }
    }
}
