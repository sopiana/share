<?php

use App\Model\FolderUser;
use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
class FolderUserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        //get All folders
        $folders = DB::table('folder_share')->select('id','creator_id')->get();
        foreach($folders as $folder)
        {
            $userNum = rand(0,5);
            for($i=0;$i<$userNum;)
            {
                try{
                    //get APPROVER and LEGAL except the creator
                    $ApproverLegals = DB::table('users')->select('id','role')->where('id', '!=', $folder->creator_id)->
                        whereIn('role',['LEGAL','APPROVER'])->get();
                    FolderUser::create(array(
                        "folder_id"=>$folder->id,
                        "user_id"=>$faker->randomElement($ApproverLegals)->id
                    ));
                    $i++;
                }
                catch(Exception $e)
                {
                    //do nothing
                }
            }
        }
    }
}
