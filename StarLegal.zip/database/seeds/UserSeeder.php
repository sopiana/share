<?php
use App\Model\User;
use Illuminate\Database\Seeder;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $users = json_decode(File::get('database/dummy/user.json'));
        foreach($users as $user)
        {
            User::create(array(
                'name'=>$user->name,
                'fullname'=>$user->fullname,
                'email'=>$user->email,
                'role'=>$user->role,
                'avatar'=>$user->avatar,
                'password'=>$user->password
            ));
        }
    }
}
