<?php

use App\Model\DocType;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(UserSeeder::class);
        $this->call(DocTypeSeeder::class);
        $this->call(FolderShareSeeder::class);
        // $this->call(FolderUserSeeder::class);
        $this->call(DocShareSeeder::class);
        $this->call(DocUserSeeder::class);

    }
}
