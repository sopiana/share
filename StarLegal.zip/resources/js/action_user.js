require('./bootstrap');
require('@coreui/coreui/dist/js/coreui');
require('datatables.net/js/jquery.dataTables');
require('datatables.net-bs4/js/dataTables.bootstrap4');
require('datatables.net-buttons-dt/js/buttons.dataTables');
const COL_DATE_WIDTH = 110;
const COL_DOCTYPE_WIDTH = 100;
const COL_PARTIES_WIDTH = 200;
const COL_STATUS_WIDTH = 80;

$(document).ready(function()
{
    let pageMenu=window.location.href.substr(window.location.origin.length+1);
    switch(pageMenu){
        case 'request':
            requestPage.drawPage();
            break;
        case 'review':
            reviewPage.drawPage();
            break;
        case 'complete':
            completePage.drawPage();
            break;
    }
});

var requestPage = {
    drawPage:function()
    {
        renderDataTable('#request-table','http://127.0.0.1:8000/dummy/userRequest.json',
            [
                {
                    data: "reqDate", width:COL_DATE_WIDTH+'px'
                    // ,render:function( data, type, row )
                    // {
                    //     return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+row.project_code+'</a>';
                    // }
                },
                { data: "docType", width:COL_DOCTYPE_WIDTH+'px'
                //     render: function ( data, type, row ) {
                //         return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+
                //             '<img class="img-avatar pr-2" src="'+window.location.origin+'/'+row.avatar +'" width="30px">'+ row.name+
                //             '</a>';}
                },
                { data: "parties", width:COL_PARTIES_WIDTH+'px'},
                { data: "purpose"},
                { data: "status",width:COL_STATUS_WIDTH+'px'
                //     render: function ( data, type, row ) {
                //         return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+
                //             '<img class="img-avatar pr-2" src="'+window.location.origin+'/'+row.avatar +'" width="30px">'+ row.name+
                //             '</a>';}
                }
        ],
        [
            {
                text:'<i class="fa fa-plus pr-2"></i> New Request',
                className:'btn btn-square btn-primary',
                action:function(e, dt, node, config){
                    alert('Button Pressed');
                }
            }
        ]);
    }
}

var reviewPage = {
    drawPage:function()
    {
        renderDataTable('#review-table','http://127.0.0.1:8000/dummy/userRequest.json',
            [
                {
                    data: "reqDate", width:COL_DATE_WIDTH+'px'
                    // ,render:function( data, type, row )
                    // {
                    //     return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+row.project_code+'</a>';
                    // }
                },
                { data: "docType", width:COL_DOCTYPE_WIDTH+'px'
                //     render: function ( data, type, row ) {
                //         return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+
                //             '<img class="img-avatar pr-2" src="'+window.location.origin+'/'+row.avatar +'" width="30px">'+ row.name+
                //             '</a>';}
                },
                { data: "parties", width:COL_PARTIES_WIDTH+'px'},
                { data: "purpose"},
                { data: "status",width:COL_STATUS_WIDTH+'px'
                //     render: function ( data, type, row ) {
                //         return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+
                //             '<img class="img-avatar pr-2" src="'+window.location.origin+'/'+row.avatar +'" width="30px">'+ row.name+
                //             '</a>';}
                }
        ],
        [
            {
                text:'<i class="fa fa-plus pr-2"></i> New Review',
                className:'btn btn-square btn-primary',
                action:function(e, dt, node, config){
                    alert('Button Pressed');
                }
            }
        ]);
    }
}

var completePage = {
    drawPage:function()
    {
        renderDataTable('#complete-table','http://127.0.0.1:8000/dummy/userComplete.json',
            [
                { data: "docType", width:COL_DOCTYPE_WIDTH+'px'
                //     render: function ( data, type, row ) {
                //         return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+
                //             '<img class="img-avatar pr-2" src="'+window.location.origin+'/'+row.avatar +'" width="30px">'+ row.name+
                //             '</a>';}
                },
                {
                    data: "activities", width:COL_DATE_WIDTH+'px'
                    // ,render:function( data, type, row )
                    // {
                    //     return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+row.project_code+'</a>';
                    // }
                },
                {
                    data: "completeDate", width:COL_DATE_WIDTH+'px'
                    // ,render:function( data, type, row )
                    // {
                    //     return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+row.project_code+'</a>';
                    // }
                },
                { data: "parties", width:COL_PARTIES_WIDTH+'px'},
                { data: "purpose",
                    render:function( data, type, row )
                    {
                        return '<a href="#" class="btn btn-square btn-block btn-primary active">Revise</a>';
                    }
                },
                { data: "latestVersion",width:COL_STATUS_WIDTH+'px',
                    render: function ( data, type, row ) {
                        return row.latestVersion + '<a href="' + window.location.origin+'/project/'+row.project_code+'">'+
                            '<i class="icon-reload pl-2"></i>'+
                            '</a>';
                    }
                }
        ],
        null);
    }
}

function renderDataTable(container, url, columnDefinitions, btnSetting)
{
    var setting = {
        colReorder:true,
        pageLength:25,
        columns:columnDefinitions,
        processing: false,
        serverSide: false,
        ajax:null,
        // dom:null,
        buttons: null,
    }
    if(url!=null)
        setting.ajax = url;
    if(btnSetting!=null)
    {
        setting.dom='Bfrtip';
        setting.buttons = btnSetting;
    }
    console.log('setting:'+setting.dom);
    $(container).DataTable().destroy();
    return $(container).DataTable(setting);
}
