require('./bootstrap');
require('@coreui/coreui/dist/js/coreui');
require('datatables.net/js/jquery.dataTables');
require('datatables.net-bs4/js/dataTables.bootstrap4');
require('datatables.net-buttons-dt/js/buttons.dataTables');
require('datatables.net-select/js/dataTables.select.min');
require('./quill');
require('bootstrap-fileinput/js/fileinput');
require('magicsuggest/magicsuggest');
window.Quill = require('Quill');
const COL_DATE_WIDTH = 70;
const COL_DOCTYPE_WIDTH = 100;
const COL_PARTIES_WIDTH = 200;
const COL_STATUS_WIDTH = 80;
var ACC='USER';
$(document).ready(function()
{
    let pageMenu=window.location.href.substr(window.location.origin.length+1);
    if(pageMenu.indexOf('/')>0)
        pageMenu = pageMenu.substr(0,pageMenu.indexOf('/'));
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": false,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "3000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
        }
    ACC=$('#acc_token').val();
    $.ajax({
        type: 'GET',
        url: window.location.origin+'/api/getDocType',
        data: { get_param: 'value' },
        success: function (data) {
            switch(pageMenu){
                case 'request':
                    requestPage.drawPage();
                    requestPage.assignAction();
                    break;
                case 'review':
                    reviewPage.drawPage();
                    break;
                case 'complete':
                    completePage.drawPage();
                    break;
                case 'share':
                    sharePage.docTypeList = data;
                    sharePage.drawPage();
                    sharePage.assignAction();
                    break;
                case 'profile':
                    profilePage.drawPage();
                    profilePage.assignAction();
                    break;
            }
        }
    });
});

var requestPage = {
    req_step:1,
    drawPage:function()
    {
        let rowsDefinition = [
            { data: "reqDate", width:COL_DATE_WIDTH+'px'},
            { data: "docType", width:COL_DOCTYPE_WIDTH+'px'},
            { data: "parties", width:COL_PARTIES_WIDTH+'px'},
            { data: "purpose"},
            { data: "status", width:COL_STATUS_WIDTH+'px'}
        ];
        let buttonDefinition = [{
                text:'<i class="fa fa-th-large"></i>',
                attr:{
                    id:"dt-row-columnSelect",
                    "data-toggle":"dropdown",
                    "aria-haspopup":"true",
                    "aria-expanded":"false"
                },
                className:'btn btn-square btn-primary',
                titleAttr: 'Customize Columns'
            }];
        if(ACC=='USER')
        {
            buttonDefinition.push({
                    text:'<i class="fa fa-plus pr-2"></i> New Request',
                    className:'btn btn-square btn-primary ml-1',
                    action:function(e, dt, node, config){
                        $('#newRequestModal').modal('show');
                        requestPage.req_step=1;
                        $('.nav-tabs a[href="#step1"]').tab('show');
                        $('#submit-request-btn').text('Next');
                        $('#back-btn').text('close').attr('class','btn btn-secondary');
                    }
                });
        }
        renderDataTable('#request-table',window.location.origin+'/api/getRequestDocs',
                //doc_type 	purpose 	parties 	description 	commercial_terms 	transaction_value 	late_payment_toleration 	condition_precedent 	termination_terms 	payment_terms 	delay_penalty 	guarantee 	agreement_terms 	attch_akta 	attch_npwp 	attch_tdp 	attch_ktp 	attch_comp_profile 	attch_others 	status 	requester_id 	pic_id 	approver_id
            rowsDefinition,
            buttonDefinition,
        null);
    },
    assignAction:function()
    {
        if(ACC=='USER')
        {
            console.log('USER');

            $(document).on('click','#submit-request-btn',function(e)
            {
                requestPage.req_step++;
                if(requestPage.req_step==2)
                    $('#back-btn').text('Back').attr('class','btn btn-primary');
                if(requestPage.req_step<4)
                    $('.nav-tabs a[href="#step'+requestPage.req_step+'"]').tab('show');
                else if(requestPage.req_step==4)
                {
                    $('.nav-tabs a[href="#step'+requestPage.req_step+'"]').tab('show');
                    $(this).text('Submit')
                }
                else
                {
                    console.log('do submit request');
                }
            });
            $(document).on('click','#back-btn',function(e)
            {
                requestPage.req_step--;
                if(requestPage.req_step==3)
                    $('#submit-request-btn').text('Next');
                if(requestPage.req_step==1)
                    $(this).text('close').attr('class','btn btn-secondary');
                if(requestPage.req_step>0)
                    $('.nav-tabs a[href="#step'+requestPage.req_step+'"]').tab('show');
                else
                    $('#newRequestModal').modal('hide');
            });
        }
        $('a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            var target = $(e.target).attr("href") // activated tab
            requestPage.req_step = Number(target.replace('#step',''));
            if(requestPage.req_step==1)
                $('#back-btn').text('close').attr('class','btn btn-secondary');
            else
                $('#back-btn').text('Back').attr('class','btn btn-primary');

            if(requestPage.req_step==4)
                $('#submit-request-btn').text('Submit');
            else
                $('#submit-request-btn').text('Next');
        });
    }
}

var reviewPage = {
    drawPage:function()
    {
        renderDataTable('#review-table','http://127.0.0.1:8000/dummy/userRequest.json',
            [
                {
                    data: "reqDate", width:COL_DATE_WIDTH+'px'
                    // ,render:function( data, type, row )
                    // {
                    //     return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+row.project_code+'</a>';
                    // }
                },
                { data: "docType", width:COL_DOCTYPE_WIDTH+'px'
                //     render: function ( data, type, row ) {
                //         return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+
                //             '<img class="img-avatar pr-2" src="'+window.location.origin+'/'+row.avatar +'" width="30px">'+ row.name+
                //             '</a>';}
                },
                { data: "parties", width:COL_PARTIES_WIDTH+'px'},
                { data: "purpose"},
                { data: "status",width:COL_STATUS_WIDTH+'px'
                //     render: function ( data, type, row ) {
                //         return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+
                //             '<img class="img-avatar pr-2" src="'+window.location.origin+'/'+row.avatar +'" width="30px">'+ row.name+
                //             '</a>';}
                }
        ],
        [
            {
                text:'<i class="fa fa-plus pr-2"></i> New Review',
                className:'btn btn-square btn-primary',
                action:function(e, dt, node, config){
                    alert('Button Pressed');
                }
            }
        ],
        null);
    }
}

var completePage = {
    drawPage:function()
    {
        renderDataTable('#complete-table','http://127.0.0.1:8000/dummy/userComplete.json',
            [
                { data: "docType", width:COL_DOCTYPE_WIDTH+'px'
                //     render: function ( data, type, row ) {
                //         return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+
                //             '<img class="img-avatar pr-2" src="'+window.location.origin+'/'+row.avatar +'" width="30px">'+ row.name+
                //             '</a>';}
                },
                {
                    data: "activities", width:COL_DATE_WIDTH+'px'
                    // ,render:function( data, type, row )
                    // {
                    //     return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+row.project_code+'</a>';
                    // }
                },
                {
                    data: "completeDate", width:COL_DATE_WIDTH+'px'
                    // ,render:function( data, type, row )
                    // {
                    //     return '<a href="'+window.location.origin+'/project/'+row.project_code+'">'+row.project_code+'</a>';
                    // }
                },
                { data: "parties", width:COL_PARTIES_WIDTH+'px'},
                { data: "purpose",
                    render:function( data, type, row )
                    {
                        return '<a href="#" class="btn btn-square btn-primary active">Revise</a>';
                    }
                },
                { data: "latestVersion",width:COL_STATUS_WIDTH+'px',
                    render: function ( data, type, row ) {
                        return row.latestVersion + '<a href="' + window.location.origin+'/project/'+row.project_code+'">'+
                            '<i class="icon-reload pl-2"></i>'+
                            '</a>';
                    }
                }
        ],
        null,
        null);
    }
}

var sharePage = {
    docTypeList:null,
    newFolderDescriptionTxtArea:null,
    newFileDescriptionTxtArea:null,
    newFileRemarkTxtArea:null,
    shareDataTable:null,
    userMagicSuggest:null,
    drawPage:function()
    {
        let origin = window.location.origin;
        let shareDataTable = renderDataTable('#share-table', window.location.href.replace('/share','/api/getSharedFoldersDocs'),
            [
                { targets: 0,
                    data: null,
                    className: 'select-checkbox',
                    searchable: false,
                    orderable: false,
                    render: function (data, type, full, meta) {
                        return '<input type="checkbox" class="_check" name="check" value="' + data.doc_id + '"">';
                    }
                },
                {
                    data: "doc_name", width:COL_DOCTYPE_WIDTH+'px',
                    render:function( data, type, row )
                    {
                        if(row.type=='DOC')
                        {
                            if(window.location.origin=='http://127.0.0.1:8000')
                                return '<a class="preview-doc-btn" data-toggle="modal" href="#fileDetailModal" data-link="http://www.snee.com/xml/xslt/sample.doc">'+
                                    '<i class="fa fa-file-text-o pr-2"></i>'+row.doc_name+'</a>';
                            else
                                return '<a class="preview-doc-btn" data-toggle="modal" href="#fileDetailModal" data-link='+window.location.origin+'/'+row.attachment+'">'+
                                    '<i class="fa fa-file-text-o pr-2"></i>'+row.doc_name+'</a>';
                        }
                        else
                            return '<a href="'+origin+'/share/'+row.doc_id+'"><i class="fa fa-folder-o pr-2"></i>'+row.doc_name+'</a>';
                    }
                },
                Utils.renderColDate("date_creation","row.date_creation", true),
                { data: "company_name", width:COL_DOCTYPE_WIDTH+'px'},
                {
                    data : "doc_type",
                    visible : false,
                    render:function( data, type, row )
                    {
                        let doctypes = sharePage.docTypeList;
                        if(row.type=='DOC')
                        {
                            for(var i=0;i<doctypes.length;++i)
                            {
                                if(doctypes[i].id==row.doc_type)
                                    return doctypes[i].type;
                            };
                            return "undefined";
                        }
                        return "";
                    }
                },
                { data: "agreement_number", width:COL_DOCTYPE_WIDTH+'px'},
                Utils.renderColDate("agreement_date","row.agreement_date", false),
                { data: "parties", visible : false},
                Utils.renderColDate("expire_date","row.expire_date", false),
                { data: "description", visible : false},
                { data: "remark"}
        ],
        [
            {
                text:'<i class="fa fa-th-large"></i>',
                attr:{
                    id:"dt-row-columnSelect",
                    "data-toggle":"dropdown",
                    "aria-haspopup":"true",
                    "aria-expanded":"false"
                },
                className:'btn btn-square btn-primary',
                titleAttr: 'Customize Columns'
            },
            {
                text:'<i class="fa fa-folder-o"></i>',
                className:'btn btn-square btn-primary',
                titleAttr: 'New Folder',
                action:function(e, dt, node, config){
                    $('#addFolderModal').modal('show');
                }
            },
            {
                text:'<i class="fa fa-file-text-o"></i>',
                className:'btn btn-square btn-primary',
                titleAttr: 'New Document',
                action:function(e, dt, node, config){
                    $('#addFileModal').modal('show');
                }
            },
            {
                text:'<i class="fa fa-share-alt"></i>',
                attr:{
                    id:"dt-row-shareBtn",
                    disabled: true
                },
                className:'btn btn-square btn-primary',
                titleAttr: 'Share',
                action:function(e, dt, node, config){
                    $('#shareModal').modal('show');
                }
            },
            {
                text:'<i class="fa fa-download"></i>',
                attr:{
                    id:"dt-row-downloadBtn",
                    disabled: true
                },
                className:'btn btn-square btn-primary',
                titleAttr: 'Download',
                action:function(e, dt, node, config){
                    var docIds =[];
                    var formData = {};
                    sharePage.shareDataTable.rows({ selected: true }).data().toArray().forEach(element=>{
                        docIds.push({type:element.type, id:element.doc_id})
                    });
                    formData["_token"] = $('input[name="_token"]')[0].value;
                    formData["doc-ids"] = JSON.stringify(docIds);
                    toastr.info('Server is preparing the files to be downloaded','File download');
                    $.post(window.location.origin+'/api/getDownloadLinks', formData, function(response)
                    {
                        sharePage.shareDataTable.rows().deselect();
                        setTimeout(function(){
                            sharePage.downloadLoop=0;
                            sharePage.loopDownloadLinks(response.links);
                        },1000);
                    }).fail(function(response)
                    {
                        toastr.error("Server cannot provide download links to unknown issue","Server execution error");
                    });
                }
            },
            {
                text:'<i class="fa fa-remove"></i>',
                attr:{
                    id:"dt-row-deleteBtn",
                    disabled: true
                },
                className:'btn btn-square btn-primary',
                titleAttr: 'Delete',
                action:function(e, dt, node, config){
                    $('#deleteModal').modal('show');
                }
            }
        ],
        [[1, 'asc']]);

        sharePage.newFolderDescriptionTxtArea = new Quill('#folder-description', {
            modules: {
                toolbar: toolbarOptions
            },
            theme: 'snow',
            placeholder: "Description..."
        });
        sharePage.newFileDescriptionTxtArea = new Quill('#newfile-description', {
            modules: {
                toolbar: toolbarOptions
            },
            theme: 'snow',
            placeholder: "Description..."
        });
        sharePage.newFileRemarkTxtArea = new Quill('#newfile-remarks', {
            modules: {
                toolbar: toolbarOptions
            },
            theme: 'snow',
            placeholder: "Remarks..."
        });
        $("#file-attachment").fileinput({
            showUpload: false,
            previewFileIcon: '<i class="fas fa-file"></i>',
                allowedPreviewTypes: ['image', 'text'], // allow only preview of image & text files
                uploadAsync: false,
                previewFileIcon: '<i class="fa fa-file"></i>',
                allowedPreviewTypes: null, // set to empty, null or false to disable preview for all types
                previewFileIconSettings: {
                    'doc': '<i class="fa fa-file-word-o"></i>',
                    'xls': '<i class="fa fa-file-excel-o"></i>',
                    'ppt': '<i class="fa fa-file-powerpoint-o"></i>',
                    'pdf': '<i class="fa fa-file-pdf-o"></i>',
                    'zip': '<i class="fa fa-file-zip-o"></i>',
                    'txt': '<i class="fa fa-file-text-o"></i>'
                },
                previewFileExtSettings: {
                    'doc': function(ext) {
                        return ext.match(/(doc|docx)$/i);
                    },
                    'xls': function(ext) {
                        return ext.match(/(xls|xlsx)$/i);
                    },
                    'ppt': function(ext) {
                        return ext.match(/(ppt|pptx)$/i);
                    },
                    'zip': function(ext) {
                        return ext.match(/(zip|rar|tar|gzip|gz|7z)$/i);
                    },
                    'txt': function(ext) {
                        return ext.match(/(txt|ini|md)$/i);
                    }
                }
            });
        $('<div class="dropdown-menu dropdown-menu-left keep-open" id="colsel-dropdown">'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox1" class="form-check-input colsel-chkbox" type="checkbox" value="1" checked/>'+
                '<label class="form-check-label" for="colsel-chkbox1">Document Name</label></label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox2" class="form-check-input colsel-chkbox" type="checkbox" value="2" checked/>'+
                '<label class="form-check-label" for="colsel-chkbox2">Submitted Date</label></label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox3" class="form-check-input colsel-chkbox" type="checkbox" value="3" checked/>'+
                '<label class="form-check-label" for="colsel-chkbox3">Company Name</label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox4" class="form-check-input colsel-chkbox" type="checkbox" value="4"/>'+
                '<label class="form-check-label" for="colsel-chkbox4">Document Type</label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox5" class="form-check-input colsel-chkbox" type="checkbox" value="5" checked/>'+
                '<label class="form-check-label" for="colsel-chkbox5">Agreement Number</label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox6" class="form-check-input colsel-chkbox" type="checkbox" value="6" checked/>'+
                '<label class="form-check-label" for="colsel-chkbox6">Agreement Date</label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox7" class="form-check-input colsel-chkbox" type="checkbox" value="7"/>'+
                '<label class="form-check-label" for="colsel-chkbox7">Parties</label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox8" class="form-check-input colsel-chkbox" type="checkbox" value="8" checked/>'+
                '<label class="form-check-label" for="colsel-chkbox8">Expire Date</label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox9" class="form-check-input colsel-chkbox" type="checkbox" value="9"/>'+
                '<label class="form-check-label" for="colsel-chkbox9">Description</label></div>'+
            '<div class="dropdown-item">'+
                '<input id="colsel-chkbox10" class="form-check-input colsel-chkbox" type="checkbox" value="10" checked/>'+
                '<label class="form-check-label" for="colsel-chkbox10">Remarks</label></div>'+
        '</div>').insertAfter("#dt-row-columnSelect");

        $('<div class="input-group">'+
            '<input class="form-control" id="inputSearch-dtTable" type="text" name="inputSearch-dtTable" placeholder="Document name">'+
            '<span class="input-group-append">'+
            '<button class="btn btn-primary" type="button" id="btnSearch-dtTable"><i class="fa fa-search"></button>'+
            '</span>'+
        '</div>').appendTo('#share-table_filter');
        $('#share-table_filter label').remove();

        sharePage.shareDataTable = shareDataTable;
        $('#dt-row-selector').prop('checked',false);
        sharePage.userMagicSuggest = $('#username-mgcSuggest').magicSuggest(
            Utils.generateUserSuggestOption(window.location.origin+'/api/getAuthorizeUser', $('input[name="_token"]').prop('value')));
    },
    assignAction:function()
    {
        $('#frmAddFolder').submit(function(e)
        {
            var $form = $(this);
            var url = $form.attr('action');
            var formData = {};
            //submit a POST request with the form data
            $form.find('input', 'select').each(function()
            {
                if(typeof ($(this).attr('name'))!='undefined')
                    formData[ $(this).attr('name') ] = $(this).val();
            });
            formData['folder-name'] = Utils.ltrim(formData['folder-name']);
            formData[ 'description'] = sharePage.newFolderDescriptionTxtArea.container.firstChild.innerHTML;
            $.post(url, formData, function(response)
            {
                toastr.success(formData['folder-name'] +' has been created successfully',"Create Folder success");
                $('#addFolderModal').modal('hide');
                sharePage.shareDataTable.ajax.reload();
            }).fail(function(response)
            {
                let errors = response['responseJSON']['errors'];
                Array.prototype.forEach.call(Object.keys(errors), prop=>
                {
                    toastr.error(errors[prop][0],"Error on Create Folder");
                });
            });
            return false;
        });

        $('#frmAddFile').submit(function(e)
        {

            var $form = $(this);
            var urlDest = $form.attr('action');

            var formData = new FormData(this);
            var fileInput = document.getElementById('file-attachment');
            var file = fileInput.files[0];

            $form.find('input', 'select').each(function()
            {
                if(typeof ($(this).attr('name'))!='undefined')
                    formData.append( $(this).attr('name') , Utils.ltrim($(this).val()));
            });

            formData.append("document-type", $('#document-type').val());
            formData.append("description", sharePage.newFileDescriptionTxtArea.container.firstChild.innerHTML);
            formData.append("remark", sharePage.newFileRemarkTxtArea.container.firstChild.innerHTML);
            formData.append('file-attachment', file);

            // This new FormData instance is all you need to pass on the send() call:
            $.ajax({
                url : urlDest,
                type : 'POST',
                data : formData,
                processData: false,
                contentType: false,
                success : function(data) {
                    toastr.success(file +' has been uploaded',"Creating shared file success");
                    $('#addFileModal').modal('hide');
                    sharePage.shareDataTable.ajax.reload();
                },
                error: function (request, status, error) {
                    if(request.status=='422')
                    {
                        let errors = request['responseJSON']['errors'];
                        Array.prototype.forEach.call(Object.keys(errors), prop=>
                        {
                            toastr.error(errors[prop][0],"Error on Creating shared file");
                        });
                    }
                    else if(request.status=='413')
                        toastr.error("File to be uploaded is too large","Error on Creating shared file");
                    else
                        toastr.error("Unknown Error","Error on Creating shared file");
                }
             });
             return false;
        });

        $('#frmShareFile').submit(function(e){
            var $form = $(this);
            var url = $form.attr('action');
            var formData = {};
            var userIds = [];
            sharePage.userMagicSuggest.getSelection().forEach(element => {
                userIds.push(element.id);
            });
            var docIds =[];
            sharePage.shareDataTable.rows({ selected: true }).data().toArray().forEach(element=>{
                docIds.push({type:element.type, id:element.doc_id})
            });
            formData["_token"] = $('input[name="_token"]')[0].value;
            formData["user-ids"] = JSON.stringify(userIds);
            formData["doc-ids"] = JSON.stringify(docIds);
            $.post(url, formData, function(response)
            {
                toastr.success('Selected folder/file has been shared',"Share File/Folder success");
                $('#shareModal').modal('hide');
                sharePage.shareDataTable.ajax.reload();
            }).fail(function(response)
            {
                let errors = response['responseJSON']['errors'];
                Array.prototype.forEach.call(Object.keys(errors), prop=>
                {
                    toastr.error(errors[prop][0],"Error of sharing file");
                });
            });
            return false;
        });

        $('#frmDeleteFile').submit(function(e){
            var $form = $(this);
            var url = $form.attr('action');
            var formData = {};

            var docIds =[];
            sharePage.shareDataTable.rows({ selected: true }).data().toArray().forEach(element=>{
                docIds.push({type:element.type, id:element.doc_id})
            });
            formData["_token"] = $('input[name="_token"]')[0].value;
            formData["doc-ids"] = JSON.stringify(docIds);
            $.post(url, formData, function(response)
            {
                toastr.success('Selected folders/files been deleted successfully',"Delete Folder/File success");
                $('#deleteModal').modal('hide');
                sharePage.shareDataTable.ajax.reload();
            }).fail(function(response)
            {
                let errors = response['responseJSON']['errors'];
                Array.prototype.forEach.call(Object.keys(errors), prop=>
                {
                    toastr.error(errors[prop][0],"Error on Create Folder");
                });
            });
            return false;
        });

        $('#dt-row-selector').on('click',function(e)
        {
            var trArr = $(sharePage.shareDataTable.table().body()).children().toArray();
            if($(e.target).prop('checked'))
            {
                sharePage.shareDataTable.rows().select();
                sharePage.toggleDataTableButtons(true);
                trArr.forEach(function(value,index){
                    $(value.children[0].children[0]).prop('checked', true);
                });
            }
            else
            {
                sharePage.shareDataTable.rows().deselect();
                sharePage.toggleDataTableButtons(false);
                trArr.forEach(function(value,index){
                    $(value.children[0].children[0]).prop('checked', false);
                });
            }
        });

        $('#btnSearch-dtTable').on('click', function(e){
            let phrase = $('#inputSearch-dtTable').val();
            phrase = phrase.replace(/^[ ]+|[ ]+$/g,'')
            phrase = phrase.replace(/\s+/g, "+");
            window.location.href = window.location.origin+'/share/q/'+phrase;
        });

        $('#share-table tbody').on( 'click', 'tr', function ()
        {
            $(this).toggleClass('selected');
            let $chkBox = $($(this).children('.select-checkbox')[0].children[0]);
            if($(this).hasClass('selected'))
            {
                sharePage.shareDataTable.row(this).select();
                $chkBox.prop('checked', true);
                sharePage.toggleDataTableButtons(true);
            }
            else
            {
                sharePage.shareDataTable.row(this).deselect();
                $chkBox.prop('checked', false);
                let checked = false;
                let trArr = $(this).parent().children().toArray();
                for(var i=0;i<trArr.length;++i)
                {
                    if($(trArr[i].children[0].children[0]).prop('checked'))
                    {
                        checked = true;
                        break;
                    }
                }
                sharePage.toggleDataTableButtons(checked);
            }
        } );

        $('#share-table').on( 'page.dt', function () {
            $('#dt-row-selector').prop('checked',false);
            sharePage.shareDataTable.rows().deselect();
            var trArr = $(sharePage.shareDataTable.table().body()).children().toArray();
            trArr.forEach(function(value,index){
                $(value.children[0].children[0]).prop('checked', false);
            });
            sharePage.toggleDataTableButtons();
        });

        $('#colsel-dropdown').off('keydown','#colsel-dropdown');

        $('.dropdown-menu.keep-open').on('click', function (e) {
            e.stopPropagation();
        });

        $('.colsel-chkbox').change(function() {
            if(this.checked) {
                sharePage.shareDataTable.column($(this).val()).visible(true);
            }
            else
            {
                sharePage.shareDataTable.column($(this).val()).visible(false);
            }
        });

        $(document).on('click','.preview-doc-btn',function(e){
            console.log('Clicked'+$(this).data('link'))
            $('#sharedFolderPreview').attr('src','http://docs.google.com/gview?url='+$(this).data('link')+'&embedded=true');
        });
    },
    toggleDataTableButtons:function(condition)
    {
        $('#dt-row-shareBtn').prop('disabled',!condition);
        $('#dt-row-downloadBtn').prop('disabled',!condition);
        $('#dt-row-deleteBtn').prop('disabled',!condition);
    },
    downloadLoop:0,
    loopDownloadLinks:function(links){
        setTimeout(function () {
            toastr.info('Start downloading '+links[sharePage.downloadLoop],
                'Downloading '+(sharePage.downloadLoop+1)+' out of '+links.length+' documents');
            $('#file-downlod-frame').attr('src',links[sharePage.downloadLoop]);
            sharePage.downloadLoop++;
            if (sharePage.downloadLoop < links.length)
            {
               sharePage.loopDownloadLinks(links);//sampai sini
            }
         }, 3000)
    }
}

var profilePage  = {
    drawPage:function(){
        $("#avatar").fileinput({
            showUpload: false,
            allowedFileExtensions:['jpg','png','jpeg'],
            maxImageWidth:360,
            maxImageHeight:360
        });
    },
    assignAction:function(){
        $('#frm-chg-password').submit(function(e)
        {
            var $form = $(this);
            var url = $form.attr('action');
            var formData = {};
            //submit a POST request with the form data
            $form.find('input', 'select').each(function()
            {
                if(typeof ($(this).attr('name'))!='undefined')
                    formData[ $(this).attr('name') ] = $(this).val();
            });
            $.post(url, formData, function(response)
            {
                toastr.success(formData['folder-name'] +' has been created successfully',"Create Folder success");
                $('#change-pwd-modal').modal('hide');
            }).fail(function(response)
            {
                let errors = response['responseJSON']['errors'];
                Array.prototype.forEach.call(Object.keys(errors), prop=>
                {
                    toastr.error(errors[prop][0],"Change Password Failed");
                });
            });
            return false;
        });
        $('#frm-upd-profile').submit(function(e)
        {
            var $form = $(this);
            var urlDest = $form.attr('action');

            var formData = new FormData(this);

            $form.find('input', 'select').each(function()
            {
                if(typeof ($(this).attr('name'))!='undefined')
                    formData.append( $(this).attr('name') , Utils.ltrim($(this).val()));
            });

            // This new FormData instance is all you need to pass on the send() call:
            $.ajax({
                url : urlDest,
                type : 'POST',
                data : formData,
                processData: false,
                contentType: false,
                success : function(data) {
                    window.location.reload();
                },
                error: function (request, status, error) {
                    if(request.status=='422')
                    {
                        let errors = request['responseJSON']['errors'];
                        Array.prototype.forEach.call(Object.keys(errors), prop=>
                        {
                            toastr.error(errors[prop][0],"Error on Creating shared file");
                        });
                    }
                    else if(request.status=='413')
                        toastr.error("File to be uploaded is too large","Error on Creating shared file");
                    else
                        toastr.error("Unknown Error","Error on Creating shared file");
                }
             });
             return false;
        });
    }
}

function renderDataTable(container, url, columnDefinitions, btnSetting, orderType=null)
{
    var setting = {
        colReorder:true,
        pageLength:25,
        columns:columnDefinitions,
        processing: false,
        serverSide: false,
        ajax:null,
        sAjaxDataProp:"",
        // dom:null,
        buttons: null,
    }
    if(url!=null)
        setting.ajax = url;
    if(btnSetting!=null)
    {
        setting.dom='Bfrtip';
        setting.buttons = btnSetting;
    }
    if(orderType!=null)
    {
        setting.order = orderType;
    }
    $(container).DataTable().destroy();

    return $(container).DataTable(setting);
}

var Utils =
{
    monthName:['','Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'],
    getDateStr:function(date, isDatetime=true)
    {
        if(isDatetime)
            date = date.substr(0, date.indexOf(' '));
        dateComponents =date.split('-');

        return dateComponents[2]+' '+this.monthName[parseInt(dateComponents[1])]+' '+dateComponents[0];
    },
    renderColDate:function(dataEntry, date, isDateTime=true)
    {
        let ret = { data: dataEntry, width: COL_DATE_WIDTH+'px',
            sType:"date",
            render:function(data, type, row) {
                if(eval(date)==null)
                    return "";
                return '<div data-date = "'+eval(date)+'">'+Utils.getDateStr(eval(date), isDateTime)+'</div>';
            }
        }
        return ret;
    },
    ltrim:function(str) {
        if(str == null) return str;
        return str.replace(/^\s+/g, '');
    },
    generateUserSuggestOption:function(url, token){
        var userSuggestOptions =
        {
            renderer: function(data){
                return '<img class="img-avatar pr-2" src="' + window.location.origin+'/'+ data.avatar + '" width="30px"/>'+
                    data.fullname;
            },
            placeholder: 'Please enter name of user',
            method:'post',
            dataUrlParams:{_token:token},
            data: url,
            displayField: 'fullname',
            valueField: 'fullname',
            ajaxConfig: {
                xhrFields: {
                    withCredentials: true,
                }
            }
        }
        return userSuggestOptions;
    }
}

jQuery.extend(jQuery.fn.dataTableExt.oSort, {
    "date-pre":function(a){
        return $(a).data("date");
    },
    "date-asc": function( a, b ) {
        return ((a < b) ? -1 : ((a > b) ? 1 : 0));
    },
    "date-desc": function(a,b) {
        return ((a < b) ? 1 : ((a > b) ? -1 : 0));
    }
});

var toolbarOptions = [
    [{
      'header': [1, 2, 3, 4, 5, 6, false]
    }],
    ['bold', 'italic', 'underline', 'strike'], // toggled buttons
    ['blockquote', 'code-block'],
    [{
      'list': 'ordered'
    }, {
      'list': 'bullet'
    }],
    [{
      'script': 'sub'
    }, {
      'script': 'super'
    }], // superscript/subscript
    [{
      'indent': '-1'
    }, {
      'indent': '+1'
    }], // outdent/indent
    [{
      'align': []
    }],
    ['clean'] // remove formatting button
];

