<!DOCTYPE html>
<!--
* CoreUI - Free Bootstrap Admin Template
* @version v2.1.15
* @link https://coreui.io
* Copyright (c) 2018 creativeLabs Łukasz Holeczek
* Licensed under MIT (https://coreui.io/license)
-->
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <base href="./">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <meta name="description" content="Star Legal">
    <meta name="author" content="Star Legal">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ env('APP_NAME', 'Star Legal') }}</title>
    <link rel="icon" type="image/ico" href="./img/favicon.ico" sizes="any" />
    <!-- Styles -->
    <link href="{{ URL::asset('/assets/css/main.css') }}" rel="stylesheet">
</head>
@if(Route::currentRouteName()=='login')
<body class="app flex-row align-items-center">
    <div class="app-body">
    @yield('content')
    </div>
@else
<body class="app header-fixed sidebar-fixed aside-menu-fixed sidebar-lg-show">
    @include('layout.header')
    <div class="app-body">
    @include('layout.sidebar')
    @yield('content')
    </div>
    <footer class="app-footer text-center">
        <div>
            <a href="https://coreui.io">Star Legal</a>
            <span>&copy; 2019</span>
        </div>
    </footer>

    {{-- @if($userInfo->role=='USER')
    <!-- Scripts -->
    <script src="{{ URL::asset('/assets/js/action_user.js') }}" defer></script>
    @elseif($userInfo->role=='APPROVER' || $userInfo->role=='LEGAL') --}}
    <!-- Scripts -->
    <script src="{{ URL::asset('/assets/js/action_authorized.js') }}" defer></script>
    {{-- @endif --}}
@endif
</body>
@yield('modal')
</html>
