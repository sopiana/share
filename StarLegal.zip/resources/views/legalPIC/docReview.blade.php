@extends('layout.app')

@section('content')
<main class="main">
    <div class="container-fluid">
        <div class="animated fadeIn">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="icon-magnifier icon-gradient bg-arielle-smile"></i>
                </div>
                <div>Reviewed Documents</div>
            </div>
            <!-- /.card-->
            <div class="row pt-3">
                <div class="col">
                    <table id="review-table" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Date Requested</th>
                                <th>Document Type</th>
                                <th>The Parties</th>
                                <th>Purpose Agreement</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <input type="hidden" id="acc_token" name="acc_token" value="LEGAL">
    </main>
@endsection
