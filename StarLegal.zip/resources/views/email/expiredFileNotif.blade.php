<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" crossorigin="anonymous">
        <title>Expired file notification</title>
    </head>
    <body class="pl-2"  style="font-size: 0.875rem;">
        <h3>Hi, {{$username}}</h3>
        <p>Following file will be expired in {{$expirationDay}} days. For detailed information click this</p>
        <p>
            <table class="table" style="font-size: 0.875rem; max-width:60%">
                <tr>
                    <th width="200px">Document Name</th><td>{{$docData->doc_name}}</td>
                </tr>
                <tr>
                    <th>File Submisstion Date</th><td>{{$docData->created_at}}</td>
                </tr>
                <tr>
                    <th>Company Name</th><td>{{$docData->company_name}}</td>
                </tr>
                <tr>
                    <th>Document Type</th><td>{{$docData->type}}</td>
                </tr>
                <tr>
                    <th>Date of Agreement</th><td>{{$docData->agreement_date}}</td>
                </tr>
                <tr>
                    <th>Agreement Number</th><td>{{$docData->agreement_number}}</td>
                </tr>
                <tr>
                    <th>Parties</th><td>{{$docData->parties}}</td>
                </tr>
                <tr>
                    <th>Expiration Date</th><td>{{$docData->expire_date}}</td>
                </tr>
                <tr>
                    <th>Description</th><td>{{$docData->description}}</td>
                </tr>
                <tr>
                    <td class="text-center" colspan="2">
                        <a href="{{route('sharedFile',$docData->id)}}" class="btn btn-primary">Download</a>
                    </td>
                </tr>
            </table>
        </p>
    </body>
</html>
