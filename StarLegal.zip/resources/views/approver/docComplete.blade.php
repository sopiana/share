@extends('layout.app')

@section('content')
<main class="main">
    <div class="container-fluid">
        <div class="animated fadeIn">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="icon-star icon-gradient bg-malibu-beach"></i>
                </div>
                <div>Completed Documents</div>
            </div>
            <!-- /.card-->
            <div class="row pt-3">
                <div class="col">
                    <table id="complete-table" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Document Type</th>
                                <th>Activities</th>
                                <th>The Parties</th>
                                <th>Completed Date</th>
                                <th>Action</th>
                                <th>Latest Version</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <input type="hidden" id="acc_token" name="acc_token" value="APPROVER">
    </main>
@endsection
