<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DocRequest extends Model
{
    protected $table = 'doc_request';
    protected $fillable = [
        'doc_type', 'purpose', 'parties','description',
        'commercial_terms','transaction_value','late_payment_toleration',
        'condition_precedent','termination_terms','payment_terms','delay_penalty','guarantee',
        'agreement_terms','attch_akta','attch_npwp','attch_tdp','attch_ktp','attch_comp_profile',
        'attch_others','requester_id'
    ];
}
