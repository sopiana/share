<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DocType extends Model
{
    protected $table = 'doc_type';
}
