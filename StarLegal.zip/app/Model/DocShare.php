<?php

namespace App\Model;

use Illuminate\Support\Facades\DB;
use Illuminate\Database\Eloquent\Model;



class DocShare extends Model
{
    protected $table = 'doc_share';
    protected $fillable = [
        'folder_id', 'doc_name', 'company_name','doc_type',
        'agreement_date','agreement_number','parties',
        'expire_date','remark','description','attachment','submitter_id'
    ];

    const VIEW = 'doc_share_view';

    public static function getSharedDocView($userId, $folder)
    {
        return DB::table(DocShare::VIEW)->
            where(function($query) use ($userId){
                $query->where(DocShare::VIEW.'.user_id', $userId)->
                orWhere(DocShare::VIEW.'.submitter_id',$userId);
            })->
            where(DocShare::VIEW.'.folder_id', $folder)->
            groupBy(DocShare::VIEW.'.doc_id');
    }

    public static function searchSharedDoc($userId, $phrase)
    {
        return DB::table(DocShare::VIEW)->
            where(function($query) use ($userId){
                $query->where(DocShare::VIEW.'.user_id', $userId)->
                orWhere(DocShare::VIEW.'.submitter_id',$userId);
            })->
            where(DocShare::VIEW.'.doc_name', 'like', '%'.$phrase.'%')->
            groupBy(DocShare::VIEW.'.doc_id');
    }

    public static function getNearExpiredDocument()
    {
        $currentDay = time();
        $now = date('Y-m-d',$currentDay);
        $nowP5 = date('Y-m-d', strtotime('+5 day',$currentDay));
        $nowP15 = date('Y-m-d', strtotime('+15 day',$currentDay));
        $nowP30 = date('Y-m-d', strtotime('+30 day',$currentDay));

        return DocShare::select(DB::raw('doc_share.*, doc_type.type'))->whereBetween('expire_date', [$now, $nowP5])->
            orWhere(function($query) use ($nowP15, $nowP30) {
                $query->whereIn('expire_date', [$nowP15,$nowP30]);
            })->join('doc_type','doc_share.doc_type','doc_type.id');
    }
}
