<?php

namespace App\Http\Controllers;

use App\Model\DocRequest;
use App\Model\DocShare;
use App\Model\DocType;
use App\Model\FolderShare;
use App\Model\DocUser;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Model\User;
use Illuminate\Support\Facades\DB;
class ApiController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function getRequestDocs()
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='USER')
        {
            return response()->json(DocRequest::all());
        }
        else
            abort(404);
    }
    public function getSharedFolders($folderId=null){
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            return response()->json(FolderShare::getSharedFolderView(Auth::user()->id, $folderId)->get());
        }
        else
            return abort(404);
    }

    public function getSharedDocs($folderId=null){
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            return response()->json(DocShare::getSharedDocView(Auth::user()->id, $folderId)->get());
        }
        else
            return abort(404);
    }

    public function getSharedFoldersDocs($folderId=null, $phrase=null)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            if($folderId=='q')
            {
                if($phrase==null)
                    abort(404);
                $phrase = str_replace('+','%',$phrase);

                return response()->json(FolderShare::searchSharedFolder(Auth::user()->id, $phrase)->
                    unionAll(DocShare::searchSharedDoc(Auth::user()->id, $phrase))->
                    orderBy(DB::raw("CASE
                        WHEN doc_name LIKE '".$phrase."' THEN 1
                        WHEN doc_name LIKE '".$phrase."%' THEN 2
                        WHEN doc_name LIKE '%".$phrase."' THEN 4
                        ELSE 3
                        END"))->
                    get());
            }
            else
                return response()->json(FolderShare::getSharedFolderView(Auth::user()->id, $folderId)->
                    unionAll(DocShare::getSharedDocView(Auth::user()->id, $folderId))->
                    orderBy('doc_name','asc')->
                    get());
        }
        else
            return abort(404);
    }

    public function getDocPath($folder=null)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;

        if($role=='LEGAL' || $role=='APPROVER')
        {
            return response()->json(FolderShare::getFolderPath($folder));
        }
        else
            return abort(404);
    }

    public function getDocType()
    {
        return response()->json(DocType::select('id', 'type', 'description', 'sla_min','sla_max')->get());
    }

    public function getAuthorizeUser()
    {
        return response()->json(User::select('id','name','fullname','avatar')->
            whereIn('role', array('APPROVER','LEGAL'))->orderBy('fullname', 'ASC')->get());
    }

    public function getDownloadLinks(Request $request)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            $request->validate(array(
                "doc-ids"=>"required",
            ));

            $docIds = json_decode($request->input("doc-ids"));

            $links = ApiController::getFileLink($docIds, array());
            return response()->json(['success'=>'done','links' => $links]);
        }
        else
            abort(404);
    }

    static function getFileLink($docIds, $links)
    {
        foreach($docIds as $docId)
        {
            if($docId->type=='FOLDER')
            {
                $docs = DocShare::select('id', DB::raw("'DOC' as type"))->
                    where('folder_id', $docId->id)->
                    where('submitter_id', Auth::user()->id);
                $docs = DocUser::select('doc_user.doc_id as id', DB::raw("'DOC' as type"))->
                    where('doc_user.user_id', Auth::user()->id)->
                    where('doc_share.folder_id', $docId->id)->
                    join('doc_share','doc_share.id', '=', 'doc_user.doc_id')
                    ->union($docs);

                $links = ApiController::getFileLink($docs->get(), $links);

                $folders = FolderShare::select('id', DB::raw("'FOLDER' as type"))->where('folder_id', $docId->id)->get();
                $links = ApiController::getFileLink($folders, $links);
            }
            else
            {
                array_push($links,route('sharedFile',[$docId->id]));
            }
        }
        return $links;
    }
}
