<?php

namespace App\Http\Controllers;

use App\Model\DocShare;
use App\Model\DocType;
use App\Model\DocUser;
use App\Model\FolderShare;
use App\Model\User;
use App\Rules\MatchOldPassword;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $userInfo = Auth::user();
        switch($userInfo->role)
        {
            case 'USER':
                return view('user.dashboard')->with('userInfo',$userInfo);
            case 'APPROVER':
                return view('approver.dashboard')->with('userInfo',$userInfo);
            case 'LEGAL':
                return view('legalPIC.dashboard')->with('userInfo',$userInfo);
            default:
                return abort(404);
        }
    }

    public function request()
    {
        $userInfo = Auth::user();
        switch($userInfo->role)
        {
            case 'USER':
                return view('user.docRequest')->with('userInfo',$userInfo)->
                    with('doctypes',DocType::select('id', 'type')->get());
            case 'APPROVER':
                return view('approver.docRequest')->with('userInfo',$userInfo)->
                    with('doctypes',DocType::select('id', 'type')->get());
            case 'LEGAL':
                return view('legalPIC.docRequest')->with('userInfo',$userInfo)->
                    with('doctypes',DocType::select('id', 'type')->get());
            default:
                return abort(404);
        }
    }

    public function review()
    {
        $userInfo = Auth::user();
        switch($userInfo->role)
        {
            case 'USER':
                return view('user.docReview')->with('userInfo',$userInfo);
            case 'APPROVER':
                return view('approver.docReview')->with('userInfo',$userInfo);
            case 'LEGAL':
                return view('legalPIC.docReview')->with('userInfo',$userInfo);
            default:
                return abort(404);
        }
    }

    public function complete()
    {
        $userInfo = Auth::user();
        switch($userInfo->role)
        {
            case 'USER':
                return view('user.docComplete')->with('userInfo',$userInfo);
            case 'APPROVER':
                return view('approver.docComplete')->with('userInfo',$userInfo);
            case 'LEGAL':
                return view('legalPIC.docComplete')->with('userInfo',$userInfo);
            default:
                return abort(404);
        }
    }

    function profile() {
        return view('profile')->with('userInfo', Auth::user());
    }

    public function share($folder=null)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            return view('docShare')->with('userInfo', Auth::user())->
                with('folderPaths',FolderShare::getFolderPath($folder))->
                with('currentFolder',$folder)->
                with('doctypes',DocType::select('id', 'type')->get());
        }
        else
            return abort(404);
    }

    public function addFolder(Request $request)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            $request->validate([
                'folder-name'=>'required|max:256'
            ]);

            FolderShare::create(array(
                'folder_name'=> $request->input('folder-name'),
                'folder_id'=>$request->input('folder-parent'),
                'creator_id'=>Auth::user()->id,
                'description'=>$request->input('description')
            ));
            return response()->json(['success'=>'done']);
        }
        else
            return abort(404);

    }

    public function addFile(Request $request)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            $request->validate([
                'company-name'=>'required|max:1024',
                'document-type'=>'required|numeric|min:0|not_in:0|exists:doc_type,id',
                'agreement-date'=>'required',
                'agreement-number'=>'required|max:1024',
                'expire-date'=>'required',
                'file-attachment'=>'required'
            ]);
            // upload the file
            $fileName=$request->file('file-attachment')->store('shared-folder');

            $docName = $request->input('file-attachment');
            $docName = substr($docName,strrpos($docName,'\\')+1);
            DocShare::create(array(
                "folder_id"=>$request->input('folder-parent'),
                "doc_name"=>$docName,
                "company_name"=>$request->input('company-name'),
                "doc_type"=>$request->input('document-type'),
                "agreement_date"=>$request->input('agreement-date'),
                "agreement_number"=>$request->input('agreement-number'),
                "parties"=>$request->input('parties'),
                "expire_date"=>$request->input('expire-date'),
                "remark"=>$request->input('remark'),
                "description"=>$request->input('description'),
                "attachment"=>'storage/'.$fileName,
                "submitter_id"=>Auth::user()->id
            ));
            return response()->json(['success'=>'done']);
        }
        else
            return abort(404);
    }

    public function changePassword(Request $request)
    {
        $request->validate([
            'old-password'=>['required',new MatchOldPassword],
            'new-password'=>['required','min:6'],
            'confirm-password'=>['same:new-password']
        ]);
        User::find(Auth::user()->id)->update(['password'=>Hash::make(($request->input('new-password')))]);
        return response()->json(['success'=>'done']);
    }

    public function changeProfile(Request $request)
    {
        if(Auth::user()->role!='ADMIN')
        {
            $request->validate([
                'username'=>['required','max:256'],
                'fullname'=>['required','max:256'],
                'email'=>['required','email',Rule::unique('users','email')->ignore(Auth::user()->email,'email')],
                'avatar'=>['max:10240']
            ]);

            if($request->input('avatar')!=NULL)
            {
                // dd(Auth::user()->avatar);
                if(strpos(Auth::user()->avatar,'storage/')===0)
                {
                    $oldAvatar=str_replace('storage/','', Auth::user()->avatar);
                    Storage::delete($oldAvatar);
                }

                $avatar = $request->file('avatar')->store('avatar');
                User::find(Auth::user()->id)->update([
                    "name"=>$request->input('username'),
                    "fullname"=>$request->input('fullname'),
                    "email"=>$request->input('email'),
                    "avatar"=>'storage/'.$avatar
                ]);
                dd($request->input('fullname'));
            }
            else
            {
                User::find(Auth::user()->id)->update([
                    "name"=>$request->input('username'),
                    "fullname"=>$request->input('fullname'),
                    "email"=>$request->input('email')
                ]);
            }
            return response()->json(['success'=>'done']);
        }
    }

    public function doDocShare(Request $request)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            $request->validate(array(
                "user-ids"=>"required",
                "doc-ids"=>"required"
            ));
            $userIds =  json_decode($request->input("user-ids"));
            $docIds = json_decode($request->input("doc-ids"));
            DashboardController::assignDocShare($userIds, $docIds);
            return response()->json(['success'=>'done']);
        }
        else
            abort(404);
    }

    public function doDocDelete(Request $request)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            $request->validate(array(
                "doc-ids"=>"required"
            ));
            $docIds = json_decode($request->input("doc-ids"));
            DashboardController::deleteDocShare($docIds);
            return response()->json(['success'=>'done']);
        }
        else
            abort(404);
    }

    public function sharedFile($fileId)
    {
        $userInfo = Auth::user();
        $role = $userInfo->role;
        if($role=='LEGAL' || $role=='APPROVER')
        {
            $doc = DocShare::where('id',$fileId)->first();
            if(DocShare::where('id', $fileId)->where('submitter_id',$userInfo->id)->exists() ||
                DocUser::where('user_id', $userInfo->id)->where('doc_id', $fileId)->exists())
            {
                return response()->download($doc->attachment, $doc->doc_name);
            }
            else
                abort(404);
        }
        else
            abort(404);
    }

    static function assignDocShare($userIds, $docIds)
    {
        foreach($docIds as $docId)
        {
            if($docId->type=='FOLDER')
            {
                $docs = DocShare::select('id', DB::raw("'DOC' as type"))->
                    where('folder_id', $docId->id)->
                    where('submitter_id', Auth::user()->id);
                $docs = DocUser::select('doc_user.doc_id as id', DB::raw("'DOC' as type"))->
                    where('doc_user.user_id', Auth::user()->id)->
                    where('doc_share.folder_id', $docId->id)->
                    join('doc_share','doc_share.id', '=', 'doc_user.doc_id')
                    ->union($docs);

                DashboardController::assignDocShare($userIds, $docs->get());
                $folders = FolderShare::select('id', DB::raw("'FOLDER' as type"))->where('folder_id', $docId->id)->get();
                DashboardController::assignDocShare($userIds, $folders);
            }
            else
            {
                foreach($userIds as $userId)
                {
                    if(DocUser::where('user_id',$userId)->
                        where('doc_id', $docId->id)->exists()==false)
                    {
                        DocUser::create(array(
                            "doc_id"=>$docId->id,
                            "user_id"=>$userId
                        ));
                    }
                }
            }
        }
    }

    static function deleteDocShare($docIds)
    {
        foreach($docIds as $docId)
        {
            if($docId->type=='FOLDER')
            {
                $docs = DocShare::select('id', DB::raw("'DOC' as type"))->
                    where('folder_id', $docId->id)->
                    where('submitter_id', Auth::user()->id);
                $docs = DocUser::select('doc_user.doc_id as id', DB::raw("'DOC' as type"))->
                    where('doc_user.user_id', Auth::user()->id)->
                    where('doc_share.folder_id', $docId->id)->
                    join('doc_share','doc_share.id', '=', 'doc_user.doc_id')
                    ->union($docs);

                DashboardController::deleteDocShare($docs->get());
                $folders = FolderShare::select('id', DB::raw("'FOLDER' as type"))->where('folder_id', $docId->id)->get();
                DashboardController::deleteDocShare($folders);

                if(DocShare::where('folder_id',$docId->id)->exists()==false &&
                    FolderShare::where('folder_id',$docId->id)->exists()==false)
                {
                    FolderShare::where('id',$docId->id)->delete();
                }
            }
            else
            {
                try
                {
                    //TODO delete from doc user
                    $docUser = DocUser::where('doc_id',$docId->id)->delete();
                    //delete the file
                    $file = DocShare::where('id',$docId->id);
                    Storage::delete($oldAvatar=str_replace('storage/','', $file->first()->attachment));
                    $file->delete();
                }
                catch(Exception $e)
                {
                    abort(500);
                }
            }
        }
    }
}
