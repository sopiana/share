<?php

namespace App\Console\Commands;

use App\Mail\ShareDocNotifEmail;
use Illuminate\Console\Command;
use App\Model\DocUser;
use App\Model\User;
use App\Model\DocShare;
use DateTime;
use Exception;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class sendNotificationEmailCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'notification:sendFileExpirationMail';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This command will send notification email';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    public function listAllUsers()
    {
        $emailToSend = array();
        $query = DocShare::getNearExpiredDocument();
        $docsNearExpire = $query->get();
        foreach($docsNearExpire as $doc)
        {
            $now = (new DateTime())->getTimestamp();
            $expiration = (DateTime::createFromFormat('Y-m-d',$doc->expire_date))->getTimestamp();
            $expiredIn = ($expiration - $now)/86400;

            //collect submitter info
            $submitter = User::select('email', 'fullname')->where('id','=', $doc->submitter_id)->first();
            array_push($emailToSend, array(
                "recepient"=>$submitter->email,
                "remainingDays"=>$expiredIn,
                "name"=>$submitter->fullname,
                "data"=>$doc
            ));

            $sharedUsers = DocUser::select('users.fullname','users.email')->where('doc_id','=',$doc->id)->join('users','users.id','=','doc_user.user_id')->get();
            foreach($sharedUsers as $user)
            {
                array_push($emailToSend, array(
                    "recepient"=>$submitter->email,
                    "remainingDays"=>$expiredIn,
                    "name"=>$submitter->fullname,
                    "data"=>$doc
                ));
            }
        }
        return $emailToSend;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $users = $this->listAllUsers();
        foreach($users as $user)
        {
            try{
                Mail::to($user['recepient'])->send(new ShareDocNotifEmail($user));
            }
            catch(Exception $e)
            {
                Log::error($e->getMessage());
            }
        }
    }
}
