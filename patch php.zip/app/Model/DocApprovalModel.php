<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DocApprovalModel extends Model
{
    protected $table = 'doc_approval';
    public $timestamps = false;
}
