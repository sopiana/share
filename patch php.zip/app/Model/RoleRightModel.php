<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class RoleRightModel extends Model
{
    protected $table = 'role_rights';
    public $timestamps = false;
}
