<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class RightModel extends Model
{
    protected $table = 'rights';
    public $timestamps = false;
}
