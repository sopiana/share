<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Mail\ShareDocNotifEmail;
use App\Model\DocShare;
use App\Model\DocUser;
use App\Model\User;
use DateTime;

class EmailController extends Controller
{
    public function index()
    {
        $username = 'BUHead1';
        $dataDoc = $this->data['sharedDocs'];
        
        return $this->from('admin@starlegal.id')->subject('New Request Notification')->
            view('email.newRequestNotif')->
            with('username',$username)->
            with('docData', $dataDoc);
    }

    public function listAllUsers()
    {
        $query = DocShare::getNearExpiredDocument();

        $authorizedUser = User::select('users.id','users.name','users.fullname')->
            whereIn('roles.kind', array('APPROVER','LEGAL','ADMIN'))->
            join('roles','roles.id','=','users.role_id')->
            get()->toArray();

        for($i=0;$i<sizeof($authorizedUser);++$i)
        {
            $sharedDocs = clone $query;
            $sharedDocs->where(function($query) use ($authorizedUser,$i){
                $query->where('doc_share_view.submitter_id','=',$authorizedUser[$i]['id'])->
                orWhere('doc_share_view.user_id','=', $authorizedUser[$i]['id']);
            });
            $authorizedUser[$i]['sharedDocs']=($sharedDocs->get()->toArray());
        }

        return $authorizedUser;
    }
}
