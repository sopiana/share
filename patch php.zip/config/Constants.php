<?php

return [
    'DOCUMENT_ASSIGNMENT_LIMIT' => 10,
    'DOCUMENT_REVISE_LIMIT' => 10,
    'EMAIL_US_RECEPIENTS'=>['admin1@foo.com','admin2@foo.com','admin3@foo.com'],
    'BU_HEAD_ID'=> 3
];
