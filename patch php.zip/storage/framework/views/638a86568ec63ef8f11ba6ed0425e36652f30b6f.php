<?php $__env->startSection('content'); ?>
<main class="main">
    <div class="container-fluid">
        <div class="animated fadeIn">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="icon-star icon-gradient bg-malibu-beach"></i>
                </div>
                <div>Completed Documents</div>
            </div>
            <!-- /.card-->
            <div class="row pt-3">
                <div class="col">
                    <table id="generic-table" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Date Requested</th>
                                <th>Document Type</th>
                                <th>Activities</th>
                                <th>The Parties</th>
                                <th>Purpose Agreement</th>
                                <th>Completed Date</th>
                                <th>Action</th>
                                <th>Version</th>
                                <th>Status</th>
                                <th>Description</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
        <input type="hidden" id="acc_token" name="acc_token" value="USER">
        <input type="hidden" id="data-tbl-url" name="data-tbl-url" value="<?php echo e(route('getCompletedDocs')); ?>">
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal'); ?>
<!-- Modal Add Folder-->
<div class="modal fade" id="genericDocDetailModal" data-backdrop="static" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-primary" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="requestDetail-id"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#req-detail" role="tab" aria-selected="true">
                            Description
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" data-toggle="tab" href="#req-attachment" role="tab" aria-selected="false">
                            Attachment
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="req-detail" role="tabpanel">
                        <table class="table table-responsive-sm">
                            <tbody>
                                <tr>
                                    <td width="250px">Document Type</td>
                                    <td id="requestDetail-doc-type"></td>
                                </tr>
                                <tr id="proposed-by-info">
                                    <td width="250px">Proposed by</td>
                                    <td id="requestDetail-proposed-by"></td>
                                </tr>
                                <tr id="proposed-date-info">
                                    <td width="250px">Proposed Date</td>
                                    <td id="requestDetail-proposed-date"></td>
                                </tr>
                                <tr>
                                    <td>Purpose/Nature of Agreement</td>
                                    <td id="requestDetail-purpose"></td>
                                </tr>
                                <tr>
                                    <td>The Parties</td>
                                    <td id="requestDetail-parties"></td>
                                </tr>
                                <tr>
                                    <td>Description/Notes</td>
                                    <td id="requestDetail-description"></td>
                                </tr>
                                <tr>
                                    <td>Transaction/Commercial Terms</td>
                                    <td id="requestDetail-commercial"></td>
                                </tr>
                                <tr>
                                    <td>Value of Transaction</td>
                                    <td id="requestDetail-value"></td>
                                </tr>
                                <tr>
                                    <td>Toleration of Late Payment</td>
                                    <td id="requestDetail-toleration"></td>
                                </tr>
                                <tr>
                                    <td>Condition Precedent</td>
                                    <td id="requestDetail-condition"></td>
                                </tr>
                                <tr>
                                    <td>Termination Terms</td>
                                    <td id="requestDetail-termination"></td>
                                </tr>
                                <tr>
                                    <td>Term of Payment</td>
                                    <td id="requestDetail-payment"></td>
                                </tr>
                                <tr>
                                    <td>Term of Delay and Percentage Penalty</td>
                                    <td id="requestDetail-delay"></td>
                                </tr>
                                <tr>
                                    <td>Guarantee/Security</td>
                                    <td id="requestDetail-guarantee"></td>
                                </tr>
                                <tr>
                                    <td>Term of Agreement</td>
                                    <td id="requestDetail-agreement"></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane" id="req-attachment" role="tabpanel">
                        <table class="table table-responsive-sm">
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal" style="width:90px">Close</button>
            </div>
        </div>
    </div>
</div>
<!--Request Finalization Submission-->
<div class="modal fade" id="requestSubmissionModal" data-backdrop="static" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-primary" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="form-title">
                    <div class="col">
                        <h2 class="modal-title"><b>Revise Docs</b></h2>
                        <strong>Form Revision Document</strong>
                    </div>
                    <div class="col text-right sub-step" id="submit-step">
                        Upload Document
                    </div>
                </div>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <form onkeydown="return event.key!='Enter';" id="frmRequestSubmission" name="frmRequestSubmission" class="form-horizontal" action="<?php echo e(route('reviseRequest')); ?>" method="POST" enctype="multipart/form-data">
            <div class="modal-body">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" data-toggle="tab" href="#step1" role="tab" aria-selected="true">
                            Please upload file you want to revise
                        </a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane active" id="step1" role="tabpanel">
                        <div class="form-group row">
                            <div class="col-md-3 col-form-label">
                                <strong id="req-submission-docType"></strong>
                            </div>
                        </div>
                        <div class="form-group row">
                            <input type="hidden" id="req-submission-docId" type="text" name="req-submission-docId">
                            <div class="col-md-3 col-form-label">Date</div>
                            <div class="col" id="req-submission-date"></div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-3 col-form-label">Document Version</div>
                            <div class="col" id="req-submission-version"></div>
                        </div>
                        <div class="form-group row">
                            <label class="col-md-3 col-form-label" for="input-attachment">Attachment</label>
                            <div class="col">
                                <input id="input-attachment" type="file" name="input-attachment">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-md-3 col-form-label"><b>Notes</b></div>
                        </div>
                        <div class="form-group row">
                            <div class="col">
                                <div id="req-submission-notes"></div>
                            </div>
                        </div>
                        <div class="form-group row"></div>
                    </div>
                </div>
            </div>
            <?php echo csrf_field(); ?>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary" id="submit-request-btn" style="width:90px;">Submit</button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\001_Project\003_StarLegal\StarLegal\resources\views/user/docComplete.blade.php ENDPATH**/ ?>