<div class="sidebar">
    <nav class="sidebar-nav">
      <ul class="nav">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
            <i class="nav-icon icon-speedometer"></i> Dashboard
          </a>
        </li>
        <?php if($userInfo->getRoleKind()=='ADMIN'): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('userSetting')); ?>">
                <i class="nav-icon icon-people"></i> User Setting
            </a>
        </li>
        <?php endif; ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('request')); ?>">
                <i class="nav-icon icons icon-tag"></i> Requested
                <?php if($notif->request): ?>
                <span class="badge badge-pill badge-danger"><?php echo e($notif->request); ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('review')); ?>">
                <i class="nav-icon icon-magnifier"></i> Reviewed
                <?php if($notif->review>0): ?>
                <span class="badge badge-pill badge-info"><?php echo e($notif->review); ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('complete')); ?>">
                <i class="nav-icon icon-star"></i> Completed
                <?php if($notif->complete): ?>
                <span class="badge badge-pill badge-success"><?php echo e($notif->complete); ?></span>
                <?php endif; ?>
            </a>
        </li>
        <?php if($userInfo->getRoleKind()=='APPROVER' || $userInfo->getRoleKind()=='LEGAL'||$userInfo->getRoleKind()=='ADMIN'): ?>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('share')); ?>">
                <i class="nav-icon icon-cursor"></i> Shared
            </a>
        </li>
        <?php endif; ?>
      </ul>
    </nav>
    <button class="sidebar-minimizer brand-minimizer" type="button"></button>
  </div>
<?php /**PATH D:\001_Project\003_StarLegal\StarLegal\resources\views/layout/sidebar.blade.php ENDPATH**/ ?>