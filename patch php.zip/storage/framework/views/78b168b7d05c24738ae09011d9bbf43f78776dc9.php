<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" crossorigin="anonymous">
        <title>$title</title>
    </head>
    <body class="pl-2"  style="font-size: 0.875rem;">
        <?php echo e($content); ?>

    </body>
</html>
<?php /**PATH D:\001_Project\003_StarLegal\StarLegal\resources\views/email/emailUs.blade.php ENDPATH**/ ?>